// Wold - Gmail Content Script

async function isEnabled() {
  const result = await chrome.storage.sync.get(['gmailEnabled']);
  return result.gmailEnabled !== false; // default on
}

(async () => {
  if (!(await isEnabled())) return;
  initGmail();
})();

function initGmail() {

const LOGO_DATA_URL = "data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAH0AfQDASIAAhEBAxEB/8QAHQABAAICAwEBAAAAAAAAAAAAAAcJBggBAgUEA//EAEUQAAIBAwIFAQUFBQcDAgYDAAABAgMEBQYRBwghMUFCEiIyUWETQ1JxsRQjU4GyFWJykaGiwTSC8DPCCRYkY9HxNaPh/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/ANMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADvRp1K1WFGjTlUqTkowhFbuTfRJLywFGnUrVoUaNOdSpOSjCEFvKTfRJJd2ZXxC4ba10BTx9TVmBuMbTyNJVbec9nF9N3Btb+zNbreL6o3F5QuXWlpKhba51xZxqagqRVSxsqsd1YRfaUk/vf6fz7bBcQNHaf13pa703qWwhd2NxHbqvfpT8ThLvGS36P9UwKigSVx/4Q5/hJqyWPv1O7xNw3LHZGMNoV4fhfiM15j/NdGRqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA70adStVhRo05VKk5KMIRW7k30SS8sBRp1K1aFGjTnUqTkowhBbyk30SSXdm+HKHy6U9JUbbXOubOM9QzSnY2NRbqwi10nJear/2/n245Q+XOGk4W2udc2kJ5+cVOwsakd1YJ+uS81f6fz7bTAAABjnEHR2n9eaVvNNalsY3djcx/KdKfpnCXpkvD/VPYrT4+8IdQcJdVSx+RhO5xVxKTx2RjHaFeC8P8M15j/NdC08xziFo3T+vdK3mmtSWUbqxuI9/XSn6akJemS36P9UwKigSTx84Qah4SapePyUZXeLuG5Y/IwhtCvH5P8M15j/NbojYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHejTqVqsKNGnKpUnJRhCK3cm+iSXlgKNOpWqwo0acqlSclGEIrdyb6JJeWb38onLnDSVO31zrm0hU1BOKnY2NRbqwT9cl5q/0/n2conLlT0lTtdc64tYz1BOPt2NjUW8bBPtOS81f6d/n22mAAAAAAAAAxziFo7T+vNK3mmtSWUbqxuY99vfpT8ThL0yXh/qnsVp8feEGoeEuqXj8jGV1iriUnj8jGO0K8V6X+Ga8x/muhaeY3xE0bp/X2lLzTWpLONzZXMe62U6U/TUhL0yW/R/qm0BUWCSuP/CDUHCTVTx+QUrvE3MnLHZGMdoV4r0v8M15j/NdCNQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB3o06latCjRpzqVJyUYQgt5Sb6JJLuwOKVOdWrGlShKdSclGMYrdyb7JLyzfHlG5cqWkqVrrjXVpGpqGaVSxsai3jYJ9pyXmr/T+fbnlE5c6ekaNtrjXFnGpqKpFTsrGpHdWEX2lJeav9P59tpAAAAAEI8z/AB2xvCfCfsGPdC+1VeU97S0k940Ivp9rV2e6j32XRyfbom0HHM9x4xnCjDvHY/7G/wBVXlNu1tXLeNvF9qtXrv7Pyj0ctvCTa1g5euZrUektXXMNdZG9zmCytw6tzUqS9uraVZP/ANSmvwfOmum3wpbbSgTUWZymoc3d5rN31a+yF5UdSvXrS3lOT/ReEl0SSS6HwAXGYjJWOWxlvk8Zd0Lyzuqaq0a9GanCpFro4td0fYVw8rHMBkOGGSp6fz1SreaQuau84dZTsZPvUpr8Lb3lDz3XXdSsSxGSsctjLbJ426o3dndU41aFalNThUjJbppruuoH2AADG+IejdPa90rd6a1LYxurG4XR9p0pr4akJemS36P9U2itTj/wiz3CTVjxuQUrrF3LlLHZCMdo14Lw/wAM103j/NdGWnmOcQtG6f17pW701qWxjdWNxHv66U/E4S9Mlv0f6pgVFAkrj9wg1Bwl1VLH5CM7rE3EnLHZGMNoV4fhf4ZrzH+a6EagAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO9GlUrVoUaNOdSrUkowhCO8pN9Ekl3YCjTqVq0KNGnOpUnJRhCC3lJvokku7N8eUPl0paRo2uudb2kamoakVOysakd1YRa+KSfer/T+fZyh8ukNI0rfXGubOM9QzSnY2VRJqwi18Ul2dV/7fz7bSAAAAAIR5oeO2M4U4KWOx1SlearvaTdna9428X0+2q/3U99o+prbsm0HHNDx2xvCnCPHY2VG+1VeU27W1b3jbxe6+2qfRPtHp7T+ibVc2o81ldRZy7zecv61/kbyo6te4rS3lOT/RLskuiSSXQ41BmMnqDNXeazN7WvsheVHVr16st5Tk/wBF4SXRLoj4AAAAE88rPH/I8McnSwGeq1rzSFzU9+n1lKxlJ9atNd3HzKC79Wuu+8DAC4vD5Kxy+LtspjLujd2V1SjVoVqUvahUhJbpp+UfaVwcqvHy94YZaGCz1WtdaQu6m9SCXtTsZv72mu7j+KC79WuvR2JYfJWGXxdtlMXd0byyuqaq0K9GalCpF9nFrugPtAAGOcQdH4DXmlbzTepLKF3Y3Mf++nLxOEu8ZLw/+CtTj9whz/CXVcsdfxndYm4bljsjGG0K8PwvwprzH+a6MtOMc4g6OwGvNK3em9SWMLuxuY/lOlL0zhLupLfo/wBUwKigSVx+4Qag4S6qlYZCM7rE3MpPHZGMdoV4L0y/DNeY/wA10I1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB3o0qlatCjRpzqVKklGEILeUm+iSS7sBRpVK1aFGjTnUqVJKMIQW8pN9Ekl3ZvjyicucNIU7bXGuLWFTUE4qdjY1I7qwT9UvnVf+38+zlF5cqekadrrnXFrGpqGcfbsrGot42Ca+KS81f6fz7bSAAAAAIP5nePOK4U4eeMx0qV/qu7pb2tq+sLeL3X2tXr0S67R7y+i3aDnmd484rhThpY/GzoZDVV1B/sto5bxt0/vauz3S+Uejl9Em1XJn8xk8/mbrM5m+r32Qu6jqV69aXtSnJ/+bJdkkkjnUWZymoc3d5vNX1a+yN5VdW4r1XvKcn+i8JLokkl0PgAAAAAAAAAE88qvH294YZWOBz9Svd6Ru6n7yC3lOxm/vaa/Du/egu/ddekoGAFxeHydhl8Zb5TF3lC8srmmqlGvRqKcKkX2cWujR9pXFyrcf77hfkoYDPzrXmkbqpvOC3lOxm31q015i/VDz3XXdSsPwuUsM1ibXK4u7o3dld0o1aFalL2oVIyW6afkD7gABjnEHR2A15pW803qSyhdWNzH/vpS8Tg/El4f/DK1OPvB/UPCTVDsMipXeKuW3j8jGG0K8fwv8M15j/NdC04xziFo7Aa90peaa1JZRurG5j3XSdKS+GcJemS8P8AVMCooEl8f+D+f4Sapdhfxnd4i5k5Y7IxhtCtH8MvwzXlfzXQjQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdqVOdWrGlShKdSbUYxit3JvskvLA5o06latCjRpzqVJyUYQgt5Sb6JJLuzfHlF5c6ekadrrnXFrGpqGcfbsrGpFONgn2lL51f6d/n245ReXKlpKla641zaRqahmlUsbGot1YJ9pSXmr/AE/n22lAAAAAQdzQ8eMdwpwrxuLlQvtV3lPe1tm/ajbx/i1Unvt32j6n9E2A5n+PWL4U4h4vG/ZZDVV3SbtrZv3baLTSrVfpv2j0cvot2Vz6gzGT1Bm7vNZm9q3uQvKrq3Feq95Tk/P0+iXRLohqLM5TUObu83m76tfZG8qOrXr1ZbynJ/ovCS6JJJdD4AAAAAAAAGmu4AAAAAAJ55V+P19wuyUcDnZVbzSV3V3qQXWdjNtb1aflx/FDz3XXdSgYAXFYXKWGZxNrlcXd0ruxu6UatCvSl7UKkJLdNPyj7it/lb5gMlwvyNPA5yda90jc1N6lJe9Oyk+9Sn/d36yh56tdd97E8PkrHMYu2ymLu6N5ZXVONWjXozUoVIvs013QH2gADHOIOjsBrzSl5prUllG6sbmP/fSl6ZwfiS36P9UVq8f+EGf4SaqdhfqV3ibmUpY7IxjtGtFemX4Zryv5roWmmN8QtG6f17pW703qWxjd2NwvynSmvhnCXiS36P8AVMCosElcf+EOe4SaseOv1K6xVy5Sx2QUdo14L0v8M103X810ZGoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADvRpVK1aFGjTnUq1JKMIQW8pN9Ekl3YCjTqVqsKNGnKpUnJRhCK3cm+iSXlm+HKHy6U9JUbbXOuLONTUNSPt2VjUjurBPtKS81X/t/PtzyicucNIUrbXGubOFTUM0p2NjUW6sItfFJdnV/p/PttIAAAAAhDmg474zhThJ43HTpXuq7yk3aW2+6t4vdKtV+ifaPqfySbQcc0HHfG8KMK8djJ0L/Vd5De1tZdY28Huvtauz3S77R6e0/om1XNqHM5TUObu81mr6tfZC7qOpXr1pbynJ/wDHhJdEkkug1DmcpqHN3eazd9Wv8jeVHVr3FaW8pyf6LwkuiSSXQ+AAAAAAAAE/cqXL/e8TcnT1FqKjWtdIW1T3nu4TyE0+tOm+6gn0lNfkuu7iHblQ5frvibkoaj1JSr2mkbWp3XuyyE4vrSg+6h4lNf4V13cdpOYTl601xE0lQp4Czs8JncVbqljatKkoU5U4r3aFRL0fJ94vtut05oxOPssTjbbHY21pWlna0o0qNGlBRhThFJKMUuy2SPsAp41Lg8tpvO3mDzlhWsMjZ1HSr0Kq2lCS/VNdU10aaa6M84st5nuBWL4r4GV9Ywo2Wq7OntZ3jW0a0Vu/sau3eL8PvFvddN064tRYbKaezd3hM3Y1rHI2dR0q9CqtpQkv1XlNdGmmugHngAAAABPXKvx/yHDDJ08BnatW70hdVd6kOsp2Mn3qU1+HfrKHnuuu6cCgC4vD5KxzGLtspjLujd2V1TjVo16M1KFSMlummu6PtK4OVbj9f8MMtTwOfrV7vSF1U9+n8UrGcn1q013cfxQXfuuvR2JYfI2OYxdrlMbdUbyyuqUatCvRkpQqQa3Uk/K22A+0AAY5xB0dgNeaVu9N6lsYXdjcR/KdKXicJemS8P8A4ZWpx+4Q5/hLquWPv4zusTcSbx2RUNoV4fhf4Zryv5roWnGOcQdH4DXmlbzTepLKF3Y3Mf8Avpy9M4S9Ml4f/DAqKBJXH3hBqDhLql2GQjK6xNzKTx2QjH3K8F6Zfhml3j/NbojUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHejSqV60KNGnOpVqSUYQhHeUm+iSS7sBRpVK9aFGjTnUq1JKMIQjvKTfRJJd2b5conLpT0hSt9ca4s41NRTSnZWVRJqwi18UvDqv/AG/n245ROXOGkIW+uNcWkKmoJxU7GxqR3Vgn6peHV/p/PttIAAAAAhDme48YrhThZY7GzoX+q7uD/ZbRv2o20X97WSe6XfaPRyfySbQdeaDjxi+FeEqYzGVaN7qy7p//AEtt3Vsn2q1V4S8R9T+m7Vc2fy+Tz2Zu8zmL2te5C8qurXr1ZbynJ+f/APF0S6IZ/L5PPZm6zGZvq99kLuo6levWl7Upyfz/AES7JJJHwgAAAAAAAn7lT5f77ibk6eotQ0q1ppG1q+9LrGd/OL604PuoeJTX5Lru4h25UeX694l5SnqPUlCva6PtqnV7uE8hNfd033UE+kpr6xXXdxsNxdhZ4vH2+Px1pRtLS2pqnRo0aahCnFLZRjFdEvohjLGzxmOt8fj7Wla2ltTjSo0aUFGFOEUkoxS6JJJdEfWAAAAhXmb4E4nivgZ3tjChY6rtKb/Y73bZVkuv2NXbvF+H1cW9103TmoAU8akwmW05nLvCZywr2GRs6jp16FaO0oP/AJTXVNdGmmuh5xZbzP8AAvGcWMA72wjRstVWVN/sd21sq8Vu/sar/C32fVxb3XRtOuLUmEyunM5d4POWNawyNnUdKvQqx2lCS/VPumujTTXQDzwAAAAAnjlW4+X3C/Lwwedq1rvSN1U3q01707Kb+9prv7P4oLv3XXo4HAFxWFymPzWKtsriryje2F1TVWhXozUoVIvs014PuK3+Vfj7fcLsqsHnZV73SV3U3qU1vKdlN7/vKa3+Ft+9Hz3XXo7EsLk8fmsVbZXFXlC9sbqmqlCvRmpwqRfZprwB9wAAxziDo7Aa80rd6b1LYwu7G4j+U6UvE4S7qS36P9UytPj7wh1Bwl1VKwyEJ3WJuJSeOyMY7QrwXh/hmvMf5roWnmOcQdHYDXmlbvTWpLGF1Y3Mf+6lLxOEvTJb9H/wBUUCSuP3B/UHCTVDsMgpXeJuZN4/IxhtCvFemX4ZrzH+a3RGoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADNuB2t7Xh5xLxWqr3C0Mvb2k2qlGot5QUls6lPfoqke63/07rCQBb1obVOD1ppmz1Fp2+he467h7VOpF9Yvs4yXeMk+jT7HvFXHLxxlzvCTU/wC0W/2l7grqaWRxzlsqi/HDf4ai+fns/DVlGhdV4LW2mbTUenL+F7jrqO8Kkeji10cZLvGSfdPsB74AAFc/ONwg1Po3W1/rKtd3WaweYupVFf1X7VShUk+lKr8tl0i+2yS6bbFjB52ocNi9Q4a6w2ZsqF9j7um6dehWj7UZxf0/1T7pgU8Am7mf4C5XhTmJZTGRrX2k7qptbXT96dtJ/dVfk/lLs/z6EIgAAAANgOVXl7v+Jl9S1JqOnWs9IW9Xq+sJ5CSfWFN+IJraU/ziuu7iHHKpy+3/ABNyNLUeoqNa00hb1Ost3GeQnF9adN91DfpKa+qXXdxsOxdhZ4vG22Ox9tStbS1pRo0aNKPswpwiklGKXZJJHGJx9licbbY7G2lG0s7amqVGjRgoQpwSSUYpdEj7AAAAAxbiZrnTvD3Sd1qXUt6re0o9KdNdalep6adOPqk9vy2W72SbIQ5euaXHa+1Vc6b1XZ2uCvbq4f8AY84Tf2dWLe0aM2/vfk+il2ST2TDZgAACFOZ7gTi+LGCd9YqjY6qsqTVndtbRrxW7+xq7elvs+ri3uum6c1gCnjUmEy2m87eYPOWFawyNnUdKvQqraUJL9U11TXRpprozziy3mb4D4nixhXfWKo4/VVpTatLxraNaK6/ZVduri/D6uLe66bp1yamwWX01nrzBZ2wrWGSs6jp16FVbSi/+U1s010aaa6MDzQAAAPswuLyGay1ricTZ1r2+u6ipUKFKPtTqSfZJAMJi8jm8ta4nE2da9v7uoqVChRj7U6kn2SRZpyucNsvwv4YUcFmstUvr2vWd1UoKftUbOUkt6VP6eW+zk2+m/XHeVjgFj+F2Khm83To3urbqn+9qraULOD+6pPbv+KXnt27z0AAAAA1j5t+Yqjom3uNF6LuoVdTVIuF3cx6xx0Wl236Oo0+i9Pd+EB43PZxd0xR01c8MrK1tMxmLhwndVJbShjtmmmmvvX4S7J9e6T0cP0uK1W4r1Li4qzq1qknOpUnJylKTe7bb7ts/MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEpcu/GbO8JNTfb0PtL3BXc0sjjnLpNdP3kN+kaiXnyuj8NRaALetDaqwetdM2motO39O9x91D2oTg+sX5jJd4yXlPse8Vc8vHGXO8JNTqvQdS8wN1NLI45y6TW6/eQ36RqJLo/PZ+GrKNDaqwetdM2motO38L3HXcPahOL6xfmMl3jJPo0+wHvAADz9QYfGagw11hszZUb7H3dN069CtH2ozi/D/XddmVy80PAbJ8Kcx/amMVa+0peVdra5a3lbSfX7Kr9flLzt8yyo87UOHxmoMLd4XM2dG+x95SdKvQqx3jOL7/AP7XVAU8Am/mi4D5PhTm5ZPFwr3uk7yptbXLXtStpP7mq/n8peV9T0OU7gDdcTcrHUWo6Na20jaVOveMshUT60oPuofimv8ACuu7iDlT5fbzidfx1HqKFaz0jbVNt1vGd/NPrTg/EF2lNfkuu7jYbicfZYnGW2NxtpRtLO1pqlQoUYKMKcEtlGKXZDFY+yxOMtsbjbWjaWdrTjSoUKMFGFOEVsoxS7I+wAAABi3EzXGnuHukbvU2pbv7C0odIQXWpXqP4adOPqk/8tk29kmzniXrjT3D7SV1qXUt6re0odIQXWpXqP4adOPqk/8ALbq9kmytHjrxY1FxZ1ZLLZebt7Cg3DH4+Et6dtTf9U309qXn6JJIHHbixqLixq2eWy1SVvYUXKOPx8Jb07am3/um+ntS8/RJJR9CUoTjOEnGUXumns0/mcADejlB5jo6hjaaB17e+zmUlSxuSqy6XiXalUf8X5S9fb4vi2wKaISlCanCTjKL3TT2aZvPyhcx61FG10Fr6+UczFKljclVlt+2fKnUf8X5S9fb4viDbAAACFOZzgRieLGEd9YqjYaqs6bVpebbRrpdfsau3eL8Pq4t7rpunNYAp31HhcrpzOXeEzdjWscjZ1HSr0Kq2lCS/VPumujTTXQ88sw5muBeH4sYCd5aQpWOqrOk/wBivvZ2VVLdqjV27wb7Pq4t7rpunXXX0lqWhrJ6Oq4W8WfVz+y/sP2e9R1PCS8p99+23XfbqB52GxmQzOVtcVirOteX13VVKhQpR9qdSbeySRYnyscAsfwuxcM3m4Ub3Vt3T/e1V1hZwa60qb+f4pee3bvzys8AsdwuxVPOZqFK91bd0v31bvCzg11pU/r4lLz+XeeQAAAAGsvNvzE0ND2txozRt1Tr6nrQcbm5g/ajjotfP+K9+i9Pd+Ew55t+Ymhoe1r6N0ZdUq+pq0HG5uYNSjjov/R1X4Xp7vwnoJc1691c1bm5rVK1erNzqVKknKU5N7ttvq235F1Xr3VzVubmtUr1603OpUqScpTk3u5Nvq235PzAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASny78Zs7wk1L9vQ+0vsFdyX9oY5z2U/8A7kPEai+fldH4aiwAW9aG1Vg9a6ZtNR6cvoXuOu4b06kejTXRxku8ZJ9Gn2PeKueXfjNneEmpvt6Ht3uCu5x/tHHuXSaXrhv8NRLz57Pw1ZRoXVWD1rpm01Hp2+heY+7h7UJxfWL8xku8ZJ9Gn2A94AAefn8Pi8/h7rD5qwoX+Puqbp16FeHtQnF/Nf8APg74jHWOIxlvjcZaUbOztqap0aFGChCEUtkopdkfaAAAAGLcTNc6e4e6SutS6lvFQtKHSFNbOpXqP4adOPqk/l223b2SbHEzXOneHukrrUupbxW9pR6U6a61K9T006cfVJ7flsm3sk2Vp8duLOoeLOrJZbLS/ZrChvCwx8Jt07aDf+6b6e1Lzt4SSQccdeLGouLGrJ5bL1HQsKDlHH4+Et6drTf9U3sval5+iSSj0AAAABzCUoTU4ScZRe6aezTOABvPyg8xy1BG10Fr6+SzK2p43JVpbK8XilUf8X5P19vi+LbEpohKUJqcJOMovdNPZpm8/KDzHQ1DTtNA68vVDMxUaWNyNWXS8S6KnUb+9+T9Xb4viDbAAjvjpxY05wn0pLLZiauL6upRx+PhLapdTXye3uxW6cpPt9W0mHbjlxW05wo0nPMZmoq15WThYWEJJVbqpt2XyiujlJ9l820nXVX4wazq8Yo8UndUFnIV/tIQ+z3oxp7NfY+z39j2W499+u++/U8TiZrnUPEPVt1qXUt2693Xe0IR6U6FNfDThHxFf6vdvdtsxkC1HgTxb07xZ0rHKYmorbI0IqOQx05p1Lab/qg+rjLz9GmlI5UVw41rqDh/qy01Lpq8dte272lF7unWg/ip1I+qL27fk1s0mrLeA3FvT3FrSiyeLkrbI26jHI46c96ltN/1Qez9mS7+dmmkEkAGsvNzzEUtDW9fRmjbqnW1NVh7N1cxalHHRa/ydVrql6e78Jg5tuYqjoe3uNF6NuYVtT1Yezc3MXvHHJpfydRp9F6e78J6C3NevdXNW5ua1StXqzc6lSpJylOTe7bb6tt+RcVqtxXqXFxVnVrVZOdSpOTlKUm92233bZ+YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlHl54x5zhJqlXVu6l5g7qSjkce5dJx3X7yHhVEl0fns/mouJ+5VeX2/4mZClqPUVKtZ6Qt6nWXWM8hOL606b7qG/SU1+S67uIWAaL1HitXaYx+pMHc/tOOyFFVqFTbZ7eU14ae6a8NM9o+TGWNpjMbbY6wt6VtaWtKNGhRpR9mFOEUlGMV4SSSPrAAAAY3xI1jhNA6Nv9Vagqzp2NlFOSpx9qdSTe0YRXlttLr0+Zkh52ocPjNQYW7wuYs6N7j7yk6VehVjvGcX3/8A34Aq646cV9Q8WNWzy+Wm7ewotwx+PhPena0//dN9Pal3f0SSUek28z3AbK8KczLJ46NW+0nd1WrW6fWVtJ9qVX6/KXaX59CEgAAAAAAAAB2hKUJxnCTjKL3jJPZp/M6n2YXF5HNZa1xOJs617fXdVUqFClH2p1JvskgNtOC/N3DC8O7vGa8trvJ5rG0NsbcU+rv/ABGFWXpkum8+u8d+8l72svE3XOoOIer7vU2o7r7a7rvaFOPSnQpr4acF4iv9ere7bZudwy5RtL23DK6x2td7nUuTpqU7uhL/APjpLrGNLw2n8Tfxduxp9xh4b6j4Yavraf1BQ3XWdpdwi/srqlv0nF/rHun0+TYYYAABknDbW2oOH2rbTU2mrx295bvaUX1p16b+KnUj6ov5fk1s0msbMv4S8PNR8TNX0NO6dtvanLadxcTT+ytqW+zqTfy+S7t9EBtBxS5wrO84Z2lHRFpXs9UZGi4XjrR3jjfEnCXapJ94vbZLq1v7pppc161zc1bm5rVK1erNzqVKknKU5N7ttvq235N+Nbco2j7rhXbYPTM/2XU1hGVSnlK2+95Ua96FZL0Pbpt8Hjf3lLRXU+Cy+mc/eYHPWFawyVnUdOvQqraUX+jTWzTXRpprowPNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANgOVLl9u+Jt9HUmo4VrTSNtU26bxnkJxfWnB+ILtKa/wrru4hxyp8vt7xNv4ak1FCraaRtauz7wnkJLvTpvxBNbSmvyXXdxsNxVhZYrG2+OxtrRtLO2pxpUaFGChCnBJJRil0SGKsLLFY22x2NtaNpZ21ONKhQowUYU4JbKMUuyPsAAAADGOJeuNO8PNJ3OpdTXn7PZ0fdjGK3qVpvtTpx6e1J/L5bt7JNn06G1Vg9a6Zs9Radv6d5j7uClCcWt4vzCS9Ml2afYD3gAB52osNitQ4W7wuasaF9j7ym6dehWj7UZxf8A5un3T6lcvM/wHyfCjM/2ljftr/Sl5U2trpreVvJ/dVdvPyl5/MsrPO1DhsXqHC3eFzNjRvsfeU3Tr0Kq3jOL/wDN011TAp4BNvNBwHyfCjM/2njftr7Sl5VatrlreVtJ9fsqv1+UvUl8yEgAAAAH14fG3+YyttisXaVry+uqipUKFKPtTqTb2SSAYfG3+YyttisVZ1ry+uqipUKFKPtTqSfZJFiXKxwAx/C/GU87nIUb3Vt1T/e1OkoWUX3p038/xS89l07uVfgFYcLsXDOZyFG91bd09qtVe9Gyg11pU35f4peey6d57AGE8YOGum+KGk62A1BbJy2crW7hFfa2tTxOD/Vdmu5mwAqZ4v8ADjUXDHV9bT2oKG/edrdwT+yuqficX+q7p9DDS2PjBw307xO0jX0/qC3T33na3UF+9tau3ScH+q7Nbplb9/woy9nxtjwsq5TFq+lextY3jrr7HaS3Un13UtvR336fIDyeE/D3UfErV1vpzTlt7dWe0ri4mn9lbU9+tSbXZfTu30RZdwV4Yad4WaRp4PB0ftK89p3t7OP7y6qbbe038u+0eyX+b/Tg1wz05wt0jRwOAt/aqy2neXk4r7W6q9nKT+XyXZIzkAQpzO8CsVxYwTvrFUbHVVnTas7xraNaK6/Y1duri32fVxb3XRtOawBTvqPC5XTucu8Jm7GtY5GzqOlXoVY7ShJfqn3TXRpproeeWX8zPAfD8WMK72zVLH6qtKbVne7bRrJdVSq7dXBvs+ri3ut1unXDqXB5bTWevMFnLGrY5GyqulXoVVs4yX6prqmujTTXRgecAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABsByocv8AecTMnT1JqShWttIWtTr3hPITi+tOD7qCfSU1/hXXdxDtyncv11xMyMNS6mo17XSFrU+sZZGpF9acH3UF2lNf4Y9d3GwrFY+yxWNtsbjbWjaWdrTjSoUaUFGFOEVsoxS7I5xtlaYzH29hj7aja2lvTVKjRowUIU4JbKMUuiSS7I+sAAABjHEvXGneHmk7nUmpLxW9pQW0ILrUr1H8NOC9Un/+W9kmxxK1xp7h7pO61LqW8VvaUOkYLZ1K82ulOnF/FJ/L829kmytHjtxY1DxY1ZPK5abt8fQco4/HwlvTtqb/AKpvZe1Lz9EkkDjtxY1DxZ1bLLZaTt7Cg3DH4+Et6dtTf9U3sval5+iSS9Dl34zZzhJqZVqLq3uAu5r+0cc5dJLp+8p79I1El0fldH4aiwAW96H1Tg9aaatNRadv6d7jruHtU5xfWL8xku8ZJ9Gn1R7pV1y78Zs7wk1L9tR+0vsDdyX9oY5z2U//ALkN+kai+fldH4asn0PqnB600zaai07fwvcddx3p1I9Gmu8ZLvGSfRp9gPeAAHnaiw2L1FhLvC5myo32PvKbpV6FVbxnF/8Am6a6p9Submh4D5PhTm3ksZGve6TvKm1tctbytpP7mq/n8peV9dyyo87UOGxeoMLd4bM2NC+x93TdOvQrR9qM4v8A86PwBTwCbOaDgTlOFOdlkcbCteaTvKj/AGS5fvSt5P7mq/D+UvUvruiHsPjb/MZS2xeKs615fXVRUqFCjBynUk+ySQDDYzIZnK2uKxVnWvb66qKlQoUY+1OpN9kkWJcrHAHH8L8XTzuchSvdW3VL97V+KFlB96VP6+JS89l0788rHALH8L8VTzmdp0L3Vt1D97VW0oWUH91Te3f8UvPbt3noAAAABrNzccxNHQ1vcaM0bcwranqw9m5uYveOOi1/k6rT6L0934TBzccxNDQ9rX0Zoy6p19T1ouNzcwftRx8Gv8vtXv0Xju/Ceg1xdXNxeVL2vcVatzUqOrOtObc5Tb3cnJ9W2+u51ua9e6uatzc1qlavVm51KlSTlKcm92231bb8n5gbz8oHMatQq10Dr29SzCSp43I1Zf8AWbdqdR/xPk/V2+L4tsSmiEpQnGcJOMovdNPZp/M3o5QeY6Oo4Wugte3yjm1tTx2Rqy2V4vFOo/4vyfr/AMXxBteAABC/M1wKw/FjBSvLSNKw1VZ0n+xXu2yqpbtUau3eDfZ9XFvddN05oAFPGpcHltN528wedsK1hkbOo6dehVW0oS/5TWzTXRpprozzizDmc4GYrixp53VnCjY6qsqb/Yb1rZVV3+xq7dXB+H1cW910bTrg1JhMrpzO3mDzljWscjZ1HSr0Kq2lCS/VPumujTTXQDzgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzbgdjNGZjifh8fr7JTx+BqVv3010jOXppznuvs4SfRy8L5fEgkjlU5fr/iZkqeotRUa1npG2qdZdYzyE0+tOm+6hutpTX5Lru42H4yxs8Zj7fH461oWlpb01To0KNNQhTilsoxiuiX0R1xFnY47F2tji7ejb2NvSjTt6VCKjThBJKMYpdEttttj7QAAAGL8S9cae4eaSutS6kvFb2lDpCC2dSvUa92nTXqk9v1b2SbMoKz+cHUXEHL8Wr7H64t6lhRsZyWMsoSbt40G/dqweyU3Pbdy233WzS9n2UGM8deLGoeLGrZ5bLTdvYUW44/Hwm3Ttof+6b6e1Lz9EklHoAAAACU+XfjNnOEmpftqHt3uBu5x/tHHuXSaX3kN/hqJefPZ+GosAFvWhtVYPWumbPUWnb+ne4+7h7UJx7xfmMl3jJPo0+x7xVzy8cZs7wk1Mq9B1L3A3U0shjnP3ZrdfvIeI1El0fldH4asn0LqzBa201aah05kKd7YXUE4yi17UH5hJd4yXlPsB74AA8/UGHxeoMLd4bM2NG+x93TdKvQqx3jOL/87+CL+CHADRvCvM5HMYx1sjkLqpJW1xdRTlaUX93D6/OXd/TzMAAAAAAayc2/MVb6JtbjRmi7unX1NWg4XV1CSlHHxaafVP8A9b5L0934TDtzb8xVHQ1vX0boy5p19T1Yezc3MWpRx0Wv8nVa7Lx3fhPQS5r1rm4qXFxVqVq1WbnUqTk5SnJvdtt9W2/Iuq9e6uat1dVqlevWm6lWpUk5SnJvdybfVtvrufmAAAA7QlKE4zhJxlF7xkns0/mdQBvRyg8x0NQ07TQWvb1RzMUqWOyNaXS9XZU6jf3vyfr/AMXxbYFNEJShJThJxlF7pp7NMsx5QdQa+1Dwgs7zXlpONRS9jHXlaT+3vLdL3alSP+ik+skt/rIJmAAAhXmc4E4rixgne2MaFhqqzpv9jvHHaNZfwarXVxfh9XFvddN05qAFPGpcHltN527wedsK9hkbSo6dehWjtKL/AOU11TXRpproecb5/wDxAcBw/q6Gt8/mLmnZatpyVHFujFOrdx33lTnHfrTW7ftP4W1t8Xsy0MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANsuUDmOngqlroHX185YqXs0cZkqsv+kfaNKo/wCH8pP4ez934d5U00mnun5KaDbTlA5j54Sdpw/19fOWKltSxmTrT62r8Uqsn934UvT2fu/CG8gOItSipRaaa3TXk5AEc8eeE2n+LWknicqlbZCh7U8dkIR3nbVH/VB7L2o+fo0mpGAFRXEfRWoOH+rLvTOpbN217bvdSXWnWg/hqQl6ov5/mns00Y4WoceuEenuLWlJYzJxja5KgnLH5GEN6ltN+H+KD2W8d+vdbNJqtLiPorUPD/Vl1prUtlK2vbd7xkutOtB/DUpy9UXt3/NPZpoDHAAAAAAlPl34zZzhJqb7aj9pe4G7mv7Rx7l0mv4kPEaiXnz2fhqLABb3ofVOD1npmz1Hp2/heY67h7VOcX1XzjJd4yT6NPse6Vc8vHGbO8JNTfb0PtL3BXc1/aGOctlNdvbhv8NRfPz2fhqyjQ+qcHrTTNpqLTl/TvcfdR9qE4vrF+YyXeMk+jT7Ae8AAABrJzb8xVHRFvX0bou6p1tTVYuN1cwalHHxf+jqtdl6e78JhzzccxNLQ1vX0Zo25hV1PWh7NzcxalHHxa/1qtPovHd+E9BbqvXurmrc3NapXr1pudSpUk5SnJvdybfVtvyLmtWubipcXFWdatVk51Kk5OUpyb3bbfdt+T8wAAAAAAAbV8ofLjPU0rXXmvLKUcJFqpjsdVjs71+KlRP7r5L1937vxA5QuXGWpZWuvdeWTWEi1UxuOqx63r8VKi/hfKPr7v3fi3sjGMIqMUoxXRJeDinCFOEadOKhCK2jGK2SR2AAAAR3x34r6f4TaRll8tL9ovq/tQx9hCW07mol2+kVunKXjdd20n246cVtPcJ9IzzOXmri9qpwx+PhNKpdVPkvlFbpyl4XzbSdZ/EzXOouIerbrUupbx17qs9oU47qnQp+mnTj6Yr/AF6t7ttgOJeudRcQ9V3OpNTXruLut7sILpToU037NOEfEVv+b6t7ttmMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbacn/MdLCztdA8QMg3i5bUsZk68utq+ypVZP7v5Sfw9n7vw7xxlGcVKLUotbprqmimg2x5QeY+WAla6C19ft4h7Usbkq0t3aPsqVR/w/lJ/D2fu/CG84OISjOEZwkpRkt00900cgCN+PXCTT/FnScsXk4xtslQUp47IRjvUtqj8f3oPZe1Hz36NJqSABUVxG0VqHQGq7rTWprKVre0HumusK0H8NSEvVF7d/zT2aaMcLUOPPCTT3FrSrxeVirbJUE54/IwgnUtpvx/eg9l7Ud+v0aTVaXEfRWoeH+rLvTWpbKVte273jJdadam/hqU5eqL26P809mmkGOAAAAABKfLtxmzfCTU6r0vtL3A3c0sjj/a6SXT95T36RqJefK6Pw1FgAt60PqrBa001aai05f073H3cPahOL6xfmMl3jJdmn2PeKueXnjNnuEmpVXtpTvMFdTSyGPlL3Zrp+8h12jUSXR+ez8NbKcwnNbg7XSFDH8MMgr3LZOhvUu3SlFWEGvk/vfkuqjtu/CYezzc8xFDQ9rX0Zo26hW1PWh7NzcwalDHxe//APbt2Xju/CeglzXrXNzVubmtUrV6s3OpUqScpTk3u22+rbfk5urivdXNW6uq1SvXrTdSrVqScpTk3u5Nvq2313PyAAAAAAABtbyg8uL1I7XXuvbKUcNFqrjcbVj/ANb5VWon918o+vu/d+IOnKDy5T1LUtdea8sXHBxaq47HVY9b1+KlRfwvkvX3fu/FvZCMYQUIRUYxWySXRIQjCnCMIRUYxWySWySOwAAACPOOfFfTvCjSVTL5eqq99VThj8fCSVS5qbdvpBdPal4+raT446cWNO8J9Jzy2Xqqvf1lKOPx8ZbVLmol2/uxXT2pPtuu7aTrQ4la31DxC1Zdal1LeO4u672hBbqnQpp+7Tpx9MVv+re7bYHPEzXWo+Ieq7nUmpb2VxdVntTprdUren4p04+mK/zfd7ttmMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG1/KDzHPTztdBa9vZSxEmqWNyVWW/7H8qVRv7v5S9PZ+78O9EJRnCM4SUoyW6afRopoNsOUPmPlp52egde3jeHe1LHZKrLd2j8U6jf3fhS9PZ+78Ib0A4hKM4RnCSlGS3TT3TRyAI2498I9P8WtKSxmSjG2ydBOWOyMYbztpvw/xQeyTjv17rZpNSSAKiuI2itQ6A1Xdaa1LZStb23e8WutOtB/DUhL1Rfz/NPZpoxwtP498JNP8WtJvF5OKtslbqU8dkIQTnbza7P8UHsk479fGzSarT4jaK1DoDVd1prUtlK1vbd7prrTrQfw1IS9UXt3/NPZppBjgAAAAAAAAAAAAAAbVcoXLjPU07XXuvLKUcJFqrjsdVj1vn3VSov4XyXr7/D8Qc8ofLjPUs7TXuvLJxwcWquOx1WPW+fipUX8L5L1937vxb104Rp04whFRjFbJJbJIU4RpwUIRUYxWySWySOwAAACO+OvFnTnCbSsstl5/tN9X3jYY+nJKpcz/wDbFdPak+31bSfHHXizp3hPpSWVy9T9ov66cMfj4S2qXM/+Iro5Sfb6tpOtLiZrnUPEPV11qbUl39vd13tCEd1ToU18NOnH0xX+rbb3bbAcS9cah4hatutS6kvHcXdd7QgulOhTT92nBeIrf+fVvdtsxkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANsOUTmRqYCVnoLXt454htUsdkqst3aeI0qj/h+FL09n7vw7zQnGpCM4SUoyW6ae6aKaTa7lD5j6mnqlpoPXt654eW1LHZGrLrZvsqdR/w/lL0+fd+EN6gcQlGcFOElKMlumuqaOQBG3HrhHp7izpWWMykI22ToJyx2RjDepbTfj+9B7JOL7+Nmk1JIAqK4j6K1BoDVl3prUtm7a9t3upLrTrQfw1IS9UX8/wA09mmljhafx74SYDi1pN4vJpW2St1KeOyEY7ztpvw/xQeyUo79fGzSarU4j6J1Fw/1Xc6a1NZStb2h1jJdadam9/ZqQl6ovbv+aezTSDGwAAAAAAAADavlC5cZ6knaa915ZOOEi1VxuOqx63r7qpUX8L5L1937vxA5QuXGWppWuvde2Tjg01Ux2Oqx2d6/FSov4XyXr7v3fi3rpwhTpxpwiowitoxS2SXyOYRjCChCKjFLZJLZI5AAAAR1x24saf4T6Snl8rNXF/WThj8fCW1S5qbf7YLvKXj6tpNx34s6e4TaSllsrL9ov66lDH4+Etp3NRL/AGxW6cpPtuu7aTrS4l651FxD1Zc6k1LeO4u63uwhHpToU037NOC8RW/5vq3u22BzxN11qLiJq251LqW8de6rP2adOO6p29PduNOnF9orf831b3bbMYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2u5QeY2enp2ugteXrlh5NU8dka0utm/FOo3938n6e3w/DvRTnCpCM6clKElvFp7poppNr+T/AJjJaeqWugdeXzeHltSxuRqy/wCjfZUqjf3fyfp7P3fhDekHWE4VIRnCSlGS3TT3TR2AEbceuEmn+LOk5YvJwjbZOgpSx2RjDepbTfj+9B7JSjv17rZpNSSAKieIui9QaB1Xdaa1LZStb23fR94VoempCXqi9uj/ADT2aaMdLT+PfCPT/FrScsZkoq2ydupTx2QjHedvNrs/xQeyUo+e62aTVafEbReodAarutNalsna3tu9011p1oP4akJeqL+f5p7NNIMcAAAA2p5Q+XKep6lrrzXli44KLVTHY+rHrevxUqL+F8l6+/w/EHPKBy5y1NUtde68sZRwcGqmOx1WOzvn4qTT+6+S9fn3fi3spwjThGEIqMYrZJLZJCnCFOnGnTiowitopLZJHYAAABHXHbixp7hPpKeWyk43GQrJxx+PjNKpcz/4gujlLx9W0nzx14r6e4UaSqZfLVI17+snDH4+EkqlzU2/0guntS8fVtJ1ocStcah4hasutS6lvHcXdd7Qgt1ToU0/dp04+mK3/VvdtsBxJ1vqHiDqy61JqW9lcXdd7Qgt1ToQ8U6cfTFf/lvdtsxoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2v5QeY3/5d/ZtBa9vpPENqnjcjVlv+yeFSqP+H8pP4ez934d54TjUgpwkpRkt00900U0m1vKHzHPTsrXQevb2UsPJqljsjVlv+x+FTqN/dfJ+ns/d+EN6wdac41KcalOSlCS3jJPdNHYARrx74R4Di1pOWMyUY22Tt0547IxhvO2m/D/FB7JSjv17rZpMkoAVFcR9Fah4f6sutNalspW17bveMl1p1oP4alOXqi9uj/NPZppY4WoceuEmn+LOlJYzKQVtkreMpY7IRjvUtqj/AKoPZJxff6NJrXHl55TslQ1dcZbijaUP7Pxty4WthCopwvpRfSrJr7rs1F7OXqSS2YeLyh8uVTVFW113ruylDBQaqY/H1Y7O+fipNfwvkvX/AIfi3upwhTpxp04qMIrZJLokKVOFKnGnShGEIraMYrZJfQ7AAAAI646cWdOcJ9KyymXqKvf1lKOPx8JbVLmaXb+7FdPak+3Tu2k+OO3FrTnCbSrymXl+039dONhjoTSqXM//AGwXT2pPt9W0nWjxJ1tqDiDq261LqS8lcXld7QiulOhTT92nBeIrf9W922wO3EvXGoeIWrbrUupLyVxdV3tCCf7uhTTfs04LxFb/AM+re7bZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbW8oXMdLTkrTQWvLxvDNqljsjVl1s34p1G/uvk/T2fu/DvTCcakIzhJSjJbpp7poppNruULmOq6fq2mgte3sqmHk40cbkast3ZvtGlUb+68KXp7P3fhDeoHEJRnBThJSi1umnumjkAAAAAAEcceOLWnuE2k5ZTKyVzka6lDH4+EtqlxPb/AEguntS8fVtJ9uO/FjT/AAn0jLL5WSuL+tvDH2EJbTuam3+2C6OUn2+raTrS4ma51FxD1bc6l1LeO4uqz9mnTW6p29PduNOnH0xW7/Pq3u22BxxK1vqHiFq261LqS7de8rvaMI7qnQgvhp04+mK+X1be7bZjQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG13KJzH1NP1bTQevb5zw8tqWOyVWXWzfZUqj/h/KXp7P3fh3pjKM4qUWmmt015KaDa7lB5jZ6eqWugteXzlh5NU8dkq0+tm/FOpJ/dfJ+nt8PwhvUDrTnGpCM4SUoSW8WnumjsAI5478WdP8J9JSy2VkrjIV1KGPx8ZbTuai/SC3TlJ9vq2k3Hfizp7hPpOeVyk43ORrJxx+PjNKpcz/4gujlLx9W0nWjxI1tqHiBqu61JqW9lc3dd7Rgt1ToQ36U6cfTFfL82922wOeJWuNRcQtV3OpNTXrubut7sILpToU03tThHxFb/AKt7ttmNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG1vKFzHT05O10Hry+lLDSapY3I1Xu7N9lTqP+F8n6ez934dpuOPFrTXCvSDzOUrRuby4jKONsacl7d1U236fKC6OUvCfltJ1WH2ZPKZLJ/s/9o391efs1CNvQ+3qyn9lSj8MI7vpFbvZLoB7PEnW+oeIOrbrUupbx3F5Xe0YrpToU0/dp04+mK37fm3u22Y0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/9k=";
function getLogoUrl() { return LOGO_DATA_URL; }

function getGmailContext() {
  const messages = [];

  // Grab email thread messages
  document.querySelectorAll('.a3s.aiL, .ii.gt').forEach(el => {
    const text = el.innerText.trim();
    if (text && text.length > 5) {
      messages.push({ sender: 'Thread', text: text.slice(0, 500) });
    }
  });

  return messages.slice(-5);
}

function createGmailButton() {
  const btn = document.createElement('div');
  btn.title = 'Draft with Wold';
  btn.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;background:#000;border:1px solid #333;border-radius:50%;cursor:pointer;width:32px;height:32px;margin:0 4px;flex-shrink:0;vertical-align:middle;';
  const logoUrl = getLogoUrl();
  const img = document.createElement('img');
  img.src = logoUrl;
  img.style.cssText = 'width:22px;height:22px;object-fit:contain;mix-blend-mode:screen;display:block;';
  img.onerror = () => { btn.innerHTML = '<span style="color:#fff;font-size:11px;font-weight:700;">W</span>'; };
  btn.appendChild(img);
  return btn;
}

function showGmailModal(composeBox, btn) {
  const existing = document.getElementById('wold-gmail-modal');
  if (existing) { existing.remove(); return; }

  const modal = document.createElement('div');
  modal.id = 'wold-gmail-modal';
  modal.style.cssText = 'position:fixed;background:#111;border:1px solid #2a2a2a;border-radius:10px;box-shadow:0 8px 32px rgba(0,0,0,.8);padding:10px;width:260px;z-index:999998;font-family:-apple-system,sans-serif;';

  const textarea = document.createElement('textarea');
  textarea.id = 'wold-gmail-context-input';
  textarea.name = 'wold-gmail-context-input';
  textarea.placeholder = '';
  textarea.style.cssText = 'width:100%;background:#000;border:1px solid #2a2a2a;border-radius:6px;color:#fff;font-family:-apple-system,sans-serif;font-size:12px;line-height:1.5;padding:7px 9px;resize:none;height:64px;outline:none;box-sizing:border-box;display:block;';

  const generateBtn = document.createElement('button');
  generateBtn.style.cssText = 'display:flex;align-items:center;justify-content:center;gap:6px;width:100%;margin-top:7px;background:#000;border:1px solid #333;border-radius:6px;color:#fff;cursor:pointer;font-family:-apple-system,sans-serif;font-size:12px;font-weight:600;padding:7px;';
  const logoUrl = getLogoUrl();
  generateBtn.innerHTML = `<img src="${logoUrl}" style="width:16px;height:16px;object-fit:contain;mix-blend-mode:screen;" /> Generate`;

  modal.appendChild(textarea);
  modal.appendChild(generateBtn);

  const btnRect = btn.getBoundingClientRect();
  modal.style.bottom = (window.innerHeight - btnRect.top + 8) + 'px';
  modal.style.left = btnRect.left + 'px';

  document.body.appendChild(modal);
  textarea.focus();

  setTimeout(() => {
    document.addEventListener('click', function closeModal(e) {
      if (!modal.contains(e.target) && e.target !== btn) {
        modal.remove();
        document.removeEventListener('click', closeModal);
      }
    });
  }, 100);

  generateBtn.addEventListener('click', () => {
    const context = textarea.value.trim();
    modal.remove();
    handleGmailDraft(composeBox, btn, context);
  });

  textarea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      const context = textarea.value.trim();
      modal.remove();
      handleGmailDraft(composeBox, btn, context);
    }
  });
}

async function handleGmailDraft(composeBox, btn, extraContext = '') {
  const result = await chrome.storage.sync.get(['anthropicApiKey']);
  if (!result.anthropicApiKey) {
    showGmailToast('Add your API key in the Wold extension settings', 'warning');
    return;
  }

  const originalHTML = btn.innerHTML;
  btn.innerHTML = '<span style="letter-spacing:2px;opacity:.7">...</span>';
  btn.style.pointerEvents = 'none';

  try {
    const messages = getGmailContext();
    const conversationText = messages.map(m => m.text).join('\n\n---\n\n');

    const response = await chrome.runtime.sendMessage({
      type: 'DRAFT_REPLY',
      payload: {
        conversation: conversationText,
        extraContext,
        apiKey: result.anthropicApiKey,
        platform: 'gmail'
      }
    });

    if (response.error) {
      showGmailToast('Error: ' + response.error, 'error');
      return;
    }

    if (response.draft) {
      try {
        // Extract subject line if present
        let draft = response.draft;
        let subject = null;

        const subjectMatch = draft.match(/^SUBJECT:\s*(.+)\n/i);
        if (subjectMatch) {
          subject = subjectMatch[1].trim();
          draft = draft.replace(/^SUBJECT:\s*.+\n\n?/i, '');
        }

        // Insert subject into Gmail's subject field if found and field is empty
        if (subject) {
          const subjectField = document.querySelector(
            'input[name="subjectbox"], input[aria-label="Subject"], [data-hm="s"] input, .aoT'
          );
          if (subjectField && !subjectField.value.trim()) {
            subjectField.value = subject;
            subjectField.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }

        composeBox.focus();
        const signature = composeBox.querySelector('.gmail_signature, [data-smartmail="gmail_signature"]');

        if (signature) {
          const range = document.createRange();
          let sigNode = signature;
          while (sigNode.parentNode !== composeBox) sigNode = sigNode.parentNode;
          range.setStart(composeBox, 0);
          range.setEndBefore(sigNode);

          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);

          document.execCommand('delete', false, null);

          const lines = draft.split('\n');
          lines.forEach((line, i) => {
            if (i > 0) document.execCommand('insertParagraph', false, null);
            if (line) document.execCommand('insertText', false, line);
          });

          document.execCommand('insertParagraph', false, null);
          document.execCommand('insertParagraph', false, null);

        } else {
          document.execCommand('selectAll', false, null);
          document.execCommand('delete', false, null);
          const lines = draft.split('\n');
          lines.forEach((line, i) => {
            if (i > 0) document.execCommand('insertParagraph', false, null);
            if (line) document.execCommand('insertText', false, line);
          });
        }

        try { composeBox.dispatchEvent(new Event('input', { bubbles: true })); } catch(e) {}
        showGmailToast('Draft ready — review before sending!', 'success');

      } catch(insertErr) {
        console.error('[Wold] Insert error:', insertErr);
        showGmailToast('Draft ready but could not insert — try again.', 'warning');
      }
    }

  } catch (err) {
    showGmailToast('Something went wrong.', 'error');
  } finally {
    btn.innerHTML = originalHTML;
    btn.style.pointerEvents = '';
  }
}

function showGmailToast(message, type = 'info') {
  const existing = document.getElementById('wold-gmail-toast');
  if (existing) existing.remove();

  const colors = { success: '#88cc88', warning: '#ccaa55', error: '#cc7777', info: '#fff' };
  const color = colors[type] || '#fff';

  const toast = document.createElement('div');
  toast.id = 'wold-gmail-toast';
  toast.innerText = message;
  toast.style.cssText = `position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(12px);background:#111;color:${color};font-family:-apple-system,sans-serif;font-size:12px;font-weight:500;padding:9px 16px;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,.7);z-index:999999;opacity:0;transition:opacity .3s,transform .3s;pointer-events:none;border:1px solid #2a2a2a;`;
  document.body.appendChild(toast);

  setTimeout(() => { toast.style.opacity = '1'; toast.style.transform = 'translateX(-50%) translateY(0)'; }, 10);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

function injectGmailButton(composeBox) {
  if (composeBox.dataset.woldInjected) return;
  composeBox.dataset.woldInjected = 'true';

  const btn = createGmailButton();
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    showGmailModal(composeBox, btn);
  });

  const composeWindow = composeBox.closest('.M9, [role="dialog"], .nH');
  if (composeWindow) {
    // Try to place next to the Send button
    const sendBtn = composeWindow.querySelector('.T-I.J-J5-Ji.aoO, [data-tooltip="Send"], .gU .aoD');
    if (sendBtn) {
      sendBtn.parentElement.insertAdjacentElement('afterend', btn);
      return;
    }
    // Fallback: append to bottom toolbar
    const toolbar = composeWindow.querySelector('.btC, .aDh, [gh="bm"]');
    if (toolbar) {
      toolbar.appendChild(btn);
      return;
    }
  }

  // Last resort: after compose box
  const wrapper = document.createElement('div');
  wrapper.style.cssText = 'padding:4px 8px;';
  wrapper.appendChild(btn);
  composeBox.parentElement.insertAdjacentElement('afterend', wrapper);
}

function scanForGmailCompose() {
  document.querySelectorAll('[aria-label="Message Body"][contenteditable="true"], .Am.Al.editable[contenteditable="true"]').forEach(el => {
    injectGmailButton(el);
  });
}

const observer = new MutationObserver(() => {
  clearTimeout(window._woldGmailTimeout);
  window._woldGmailTimeout = setTimeout(scanForGmailCompose, 300);
});

observer.observe(document.body, { childList: true, subtree: true });

scanForGmailCompose();
setTimeout(scanForGmailCompose, 1000);
setTimeout(scanForGmailCompose, 3000);

} // end initGmail()
