const apiKeyInput = document.getElementById('apiKeyInput');
const saveBtn = document.getElementById('saveBtn');
const savedMsg = document.getElementById('savedMsg');
const toggleBtn = document.getElementById('toggleVisibility');
const statusBadge = document.getElementById('statusBadge');
const statusText = document.getElementById('statusText');
const linkedinBtn = document.getElementById('linkedinBtn');
const gmailBtn = document.getElementById('gmailBtn');

chrome.storage.sync.get(['anthropicApiKey', 'linkedinEnabled', 'gmailEnabled'], (result) => {
  if (result.anthropicApiKey) { apiKeyInput.value = result.anthropicApiKey; setConnected(true); }
  setToggle(linkedinBtn, result.linkedinEnabled !== false);
  setToggle(gmailBtn, result.gmailEnabled !== false);
});

function setToggle(btn, on) {
  btn.textContent = on ? 'ON' : 'OFF';
  btn.classList.toggle('on', on);
  btn.dataset.state = on ? 'on' : 'off';
}

linkedinBtn.addEventListener('click', () => {
  const newState = linkedinBtn.dataset.state !== 'on';
  setToggle(linkedinBtn, newState);
  chrome.storage.sync.set({ linkedinEnabled: newState });
});

gmailBtn.addEventListener('click', () => {
  const newState = gmailBtn.dataset.state !== 'on';
  setToggle(gmailBtn, newState);
  chrome.storage.sync.set({ gmailEnabled: newState });
});

toggleBtn.addEventListener('click', () => {
  apiKeyInput.type = apiKeyInput.type === 'password' ? 'text' : 'password';
});

saveBtn.addEventListener('click', () => {
  const key = apiKeyInput.value.trim();
  if (!key) { showMessage('Enter a key first', false); return; }
  chrome.storage.sync.set({ anthropicApiKey: key }, () => {
    setConnected(true);
    showMessage('Saved!', true);
  });
});

function setConnected(on) {
  statusBadge.className = 'status-badge ' + (on ? 'connected' : 'disconnected');
  statusText.textContent = on ? 'API key connected' : 'No API key';
}

function showMessage(msg, success) {
  savedMsg.textContent = msg;
  savedMsg.style.color = success ? '#4ade80' : '#f87171';
  setTimeout(() => { savedMsg.textContent = ''; }, 2500);
}
