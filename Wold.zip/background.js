// LinkedIn AI Reply - Background Service Worker
// Handles Anthropic API calls (avoids CORS issues from content scripts)

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'DRAFT_REPLY') {
    handleDraftReply(message.payload).then(sendResponse);
    return true; // Keep message channel open for async response
  }

  if (message.type === 'OPEN_POPUP') {
    chrome.action.openPopup?.();
    return false;
  }
});

async function handleDraftReply({ conversation, extraContext, apiKey, platform }) {
  try {
    const platformRule = platform === 'gmail'
      ? `GMAIL SPECIFIC RULES — critical:
- NEVER start with "I hope this message finds you well" or any similar opener. Start directly with the purpose.
- NEVER add any sign-off, closing or name at the end. No "Best regards", "Warm regards", "Kind regards", "Sincerely", "Thanks", "Isak", "Isak Wold" or any variation. The last line must be the last sentence of the message body, nothing after.
- Add exactly one blank line between the greeting line (e.g. "Hi Karen,") and the first sentence
- End the message body with exactly two blank lines after the last sentence
- Always start your response with a subject line on the very first line in this exact format: SUBJECT: [your subject here]
- Then add a blank line
- Then write the email body`
      : '- No sign-off needed for LinkedIn messages';

    const systemPrompt = `You are a professional messaging assistant helping Isak Wold draft replies.

RULES — always follow these without exception:
- Never use em dashes (— or –)
- Never sound corporate or robotic — be direct and human
- Write in the same language as the conversation (Norwegian, Danish, or English)
- Match the tone of the incoming message (formal if formal, casual if casual)
- No meta-commentary like "Here is a draft reply:"
- No subject lines
- Use line breaks between paragraphs where natural
${platformRule}`;

    const extraNote = extraContext ? `\n\nAdditional instructions from the user: ${extraContext}` : '';
    const conversationSection = conversation.trim()
      ? `Here is the conversation so far:\n\n${conversation}`
      : 'There is no prior conversation. Write a fresh message from scratch.';
    const userPrompt = `${conversationSection}${extraNote}\n\nWrite a reply (or fresh message if no conversation) from Isak Wold's perspective. Be natural and professional.`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 300,
        system: systemPrompt,
        messages: [
          { role: 'user', content: userPrompt }
        ]
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (response.status === 401) {
        return { error: 'Invalid API key — check it was copied fully, or add billing at console.anthropic.com/settings/billing' };
      }
      return { error: errorData.error?.message || `API error ${response.status}` };
    }

    const data = await response.json();
    const draft = data.content?.[0]?.text?.trim();

    if (!draft) {
      return { error: 'No reply generated. Try again.' };
    }

    return { draft };

  } catch (err) {
    console.error('[LinkedIn AI Reply] Background error:', err);
    return { error: 'Network error. Check your connection.' };
  }
}
